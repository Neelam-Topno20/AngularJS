
import { Component, OnInit } from '@angular/core';
import { Product } from '../products/product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  productListTitle:string='Products List';
  _listFilter:string='';

  productsList:Product[];
  products:Product[];
  error:string;


  constructor(private productService:ProductService){
    this._listFilter="";
    this.productsList=this.products;
  }
  get listFilter():string{
    return this._listFilter;
  }
  set listFilter(value:string){
    this._listFilter=value;
    this.productsList=this._listFilter?this.doProductFiltering(this._listFilter):this.products;
  }

  doProductFiltering(filterBy:string): Product[]{
    filterBy = filterBy.toLowerCase();
    return this.products.filter(product=>product.productName.toLowerCase().indexOf(filterBy)!==-1);
  }
  onRatingClicked(message:string ):void{
    this.productListTitle = 'Products List!!! ' + message;
  }
 
  
  ngOnInit() {
    this.productService.getAllProductsDetails().subscribe(
      tempProducts=>{
        this.products=tempProducts;
        this.productsList=this.products;
      }
      ,
      error=>{
        this.error=error;
      }
      );
  }
}