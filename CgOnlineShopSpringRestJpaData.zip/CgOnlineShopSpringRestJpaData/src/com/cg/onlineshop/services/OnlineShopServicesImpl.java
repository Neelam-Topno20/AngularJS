package com.cg.onlineshop.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.daoservices.ProductDAO;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;
@Component(value="onlineShopServices")
public class OnlineShopServicesImpl implements OnlineShopServices{
	@Autowired
	ProductDAO productDAO;
	@Override
	public Product acceptProductDetails(Product product) {
		product=productDAO.save(product);
		return product;
	}

	@Override
	public List<Product> getAllProductDetails() {
		List<Product> productList=productDAO.findAll();
		return productList;
	}

	@Override
	public Product getProductDetails(int productId) throws ProductDetailsNotFoundException {
		Product product=productDAO.findOne(productId);
		if(product==null)
			throw new ProductDetailsNotFoundException("Product details for productId "+productId+" not found");
		else
			return productDAO.findOne(productId);
	}

	@Override
	public void removeProductDetails(int productId) {
		productDAO.delete(productId);
	}
	

}
